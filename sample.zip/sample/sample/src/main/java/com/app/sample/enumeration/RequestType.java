package com.app.sample.enumeration;

public enum RequestType {
	POST,PUT,GET
}
